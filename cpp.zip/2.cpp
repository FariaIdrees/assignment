#include<iostream>
using namespace std;
int main() 
{
    int number=0;
    cout<<"Enter a number"<<endl;
    cin>>number;
    if(number>10)
    {
        cout<<"number is available"<<endl;
    }
    else{
        cout<<"number is'nt available"<<endl;
    }
    return 0;

}