#include <iostream>
using namespace std;
int main()
{
    int A=0;
    cout<<"enter the value"<<endl;
    cin>>A;
    if(A>=1 && A<=10)
    {
        cout<<"statement is true"<<endl;
    }
    else 
    {
        cout<<"statement is false"<<endl;
    }
    
}