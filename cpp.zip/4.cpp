#include <iostream>
using namespace std;
int main() 
{
int value=0;
cout<<"enter the value"<<endl;
cin>>value;
if(value<=0)
{
cout<<"value is negative"<<endl;
}
else
{
    cout<<"value isnt availaible"<<endl;
}
}