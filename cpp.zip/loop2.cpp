#include<iostream>
using namespace std;
int main()
{
    int num=0;
    for(num=2;num<=20;num=num+2)
    {
        cout<<num<<endl;
    }
    return 0;
}