#include<iostream>
using namespace std;
int main()
{
    int number=0;
    cout<<"enter the number"<<endl;
    cin>>number;
    if(number==5) 
    {
        cout<<"number is valid"<<endl;
    }
    else 
    {
        cout<<"number is invalid"<<endl;
    }
}