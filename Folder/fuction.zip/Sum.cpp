#include<iostream>
using namespace std;
int sumdig(int a ,int b)
{
    int add=a +b;
    return add;
}

int main() 
{ 
int x=7;
int y=8;
cout<< sumdig(x,y)<< endl;
return 0;

}